# Notcoin Clicker

Notcoin Clicker was built by the [Open Builders](https://openbuilders.xyz) team as a fun project.

Over time, it evolved into the phenomenon known as Notcoin (probably nothing)

We've decided to share the Clicker's source code with the community for a few reasons:
- clicker mechanics are trending, sharing the code might inspire or assist someone
- it has been copy pasted already 100 times
- one guy asked me to do this
- it's fun

Something was left out:
- turbo mode (rockets)
- no-API logic (anti-fraud)
- morse clicker

Perhaps we'll upload these additional features here someday.

# How to run

Pure React, just:
- `npm install`
- `npm start`

Or ~~copy~~ read the code without launching it.
Have fun.